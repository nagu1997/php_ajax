<?php
defined('_JEXEC') or die('Restricted access');
// require helper file
JLoader::register('HelloWorldHelper', dirname(__FILE__) . DS . 'helpers' . DS . 'helloworld.php');

jimport('joomla.application.component.controller');



// Set some global property
$document = JFactory::getDocument();
$document->addStyleDeclaration('.icon-48-helloworld {background-image: url(../media/com_helloworld/images/user-48x48.png);}');

//require_once JPATH_COMPONENT . '../administrator/components/com_helloworld/controller.php';

$controller = JController::getInstance('HelloWorld');
$jinput = JFactory::getApplication()->input;
$task = $jinput->get('task', "", 'STR' );
$controller->execute($task);
$controller->redirect();
?> 