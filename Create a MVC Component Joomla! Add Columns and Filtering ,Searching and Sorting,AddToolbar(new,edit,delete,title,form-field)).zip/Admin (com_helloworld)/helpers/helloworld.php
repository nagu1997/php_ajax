<?php
// No direct access to this file
defined('_JEXEC') or die;

/**
 * HelloWorld component helper.
 */
abstract class HelloWorldHelper
{
	/**
	 * Configure the Linkbar.
	 */
	public static function addSubmenu($submenu) 
	{
		JSubMenuHelper::addEntry(JText::_('my_reports'),'index.php?option=com_helloworld', $submenu == 'messages');
		JSubMenuHelper::addEntry(JText::_('COM_HELLOWORLD_SUBMENU_CATEGORIES'),'index.php?option=com_categories&view=categories&extension=com_helloworld',$submenu == 'categories');
		// set some global property
		$document = JFactory::getDocument();
		$document->addStyleDeclaration('.icon-48-helloworld ' .'{background-image: url(../media/com_helloworld/images/loginuser-48X48.png);}');
		if ($submenu == 'categories') 
		{
			$document->setTitle(JText::_('COM_HELLOWORLD_ADMINISTRATION_CATEGORIES'));
            
		}
	}

  public static function getActions($categoryId = 0)
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($categoryId)) {
			$assetName = 'com_helloworld';
			$level = 'component';
		} else {
			$assetName = 'com_helloworld.category.'.(int) $categoryId;
			$level = 'category';
		}

		$actions = JAccess::getActions('com_helloworld', $level);

		foreach ($actions as $action) {
			$result->set($action->name,	$user->authorise($action->name, $assetName));
		}

		return $result;
	} 

    public static function getIdOptions(){
		$options = array();
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->select('id As value, id as text');
		$query->from('#__helloworld AS a');
		$query->order('a.id');
		$db->setQuery($query);

		$options = $db->loadObjectList();

		if ($db->getErrorNum()) {
			JError::raiseWarning(500, $db->getErrorMsg());
		}
		//array_unshift($options, JHtml::_('select.option', '0', JText::_('COM_HELLOWORLD_NO_ID')));
		return $options;
	}

    public static function getNameOptions(){
		$options = array();
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->select('name As value,name As text');
		$query->from('#__helloworld AS a');
		$query->order('a.name');
		$db->setQuery($query);

		$options = $db->loadObjectList();

		if ($db->getErrorNum()) {
			JError::raiseWarning(500, $db->getErrorMsg());
		}
		//array_unshift($options, JHtml::_('select.option', '0', JText::_('COM_HELLOWORLD_NO_NAME')));
		return $options;
	} 

    public static function getEmailOptions(){
		$options = array();
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->select('email As value, email As text');
		$query->from('#__helloworld AS a');
		$query->order('a.email');
		$db->setQuery($query);

		$options = $db->loadObjectList();

		if ($db->getErrorNum()) {
			JError::raiseWarning(500, $db->getErrorMsg());
		}
		//array_unshift($options, JHtml::_('select.option', '0', JText::_('COM_HELLOWORLD_NO_NAME')));
		return $options;
	}

    public static function getMobilenoOptions(){
		$options = array();
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->select('mobileno As value, mobileno As text');
		$query->from('#__helloworld AS a');
		$query->order('a.mobileno');
		$db->setQuery($query);

		$options = $db->loadObjectList();

		if ($db->getErrorNum()) {
			JError::raiseWarning(500, $db->getErrorMsg());
		}

		// Merge any additional options in the XML definition.
		//$options = array_merge(parent::getOptions(), $options);

		//array_unshift($options, JHtml::_('select.option', '0', JText::_('COM_HELLOWORLD_NO_NAME')));
		return $options;
	}

	public static function getCityOptions(){
		$options = array();
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->select('city As value, city As text');
		$query->from('#__helloworld AS a');
		$query->order('a.city');
		$db->setQuery($query);

		$options = $db->loadObjectList();

		if ($db->getErrorNum()) {
			JError::raiseWarning(500, $db->getErrorMsg());
		}

		return $options;
	}
}