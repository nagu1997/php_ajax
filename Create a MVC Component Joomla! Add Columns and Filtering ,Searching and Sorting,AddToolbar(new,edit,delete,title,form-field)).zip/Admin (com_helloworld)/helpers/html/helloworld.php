<?php
defined('JPATH_BASE') or die;
abstract class JHtmlHelloworld
{
    public static function pinned($value, $i, $enabled = true, $checkbox = 'cb')
	{
		$states	= array(
			1	=> array(
				'sticky_unpublish',
				'COM_HELLOWORLD_HELLOWORLDS_PINNED',
				'COM_HELLOWORLD_HELLOWORLDS_HTML_PIN_HELLOWORLD',
				'COM_HELLOWORLD_HELLOWORLDS_PINNED',
				false,
				'publish',
				'publish' 
			),
			0	=> array(
				'sticky_publish',
				'COM_HELLOWORLD_HELLOWORLDS_UNPINNED',
				'COM_HELLOWORLD_HELLOWORLDS_HTML_UNPIN_HELLOWORLD',
				'COM_HELLOWORLD_HELLOWORLDS_UNPINNED',
				false,
				'unpublish',
				'unpublish'
			),
		);

		return JHtml::_('jgrid.state', $states, $value, $i, 'helloworld.', $enabled, true, $checkbox);
	} 
}