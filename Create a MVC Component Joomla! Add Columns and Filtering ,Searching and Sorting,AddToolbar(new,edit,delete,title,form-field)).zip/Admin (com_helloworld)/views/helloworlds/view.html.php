<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * HelloWorlds View
 */
class HelloWorldViewHelloWorlds extends JView
{
	/**
	 * HelloWorlds view display method
	 * @return void
	 */
	protected $state;

	function display($tpl = null) 
	{
		// Get data from the model
		$items = $this->get('Items');
		$pagination = $this->get('Pagination');
		
		// Check for errors.
		if (count($errors = $this->get('Errors'))) 
		{
			JError::raiseError(500, implode('<br />', $errors));
			return false;
		}
		// Assign data to the view
		$this->items = $items;
		$this->pagination = $pagination;
		$this->state = $this->get('State');

		//Following variables used more than once
		//$this->state = $this->get('State');

		//$this->listOrder = $this->escape($this->state->get('list.ordering'));
		//$this->listDirn = $this->escape($this->state->get('list.direction'));

		$this->searchterms	= $this->state->get('filter.search');

		// Set the toolbar and number of found items
		$this->addToolBar($this->pagination->total);

		// Display the template
		parent::display($tpl);

		// Set the document
		$this->setDocument();
	}

	/**
	 * Setting the toolbar
	 */
	protected function addToolBar($total=null) 
	{
		JToolBarHelper::title(JText::_('FORM DETAILS').($total?' <span style="font-size: 0.8em; vertical-align: middle;color:red;"><i>[' .$total. ']</i></span>':'<span style="font-size: 0.7em; vertical-align: middle;color:violet;"><i>[ 0 ]</i></span>'), 'helloworld');
		JToolBarHelper::deleteListX('', 'helloworlds.delete');
		JToolBarHelper::editListX('helloworld.edit');
		JToolBarHelper::addNewX('helloworld.add');
	}

	

	/**
	 * Method to set up the document properties
	 *
	 * @return void
	 */
	protected function setDocument() 
	{
		$document = JFactory::getDocument();
		$document->setTitle(JText::_('FORM DETAILS ADMINISTRATION'));
	}

	/*public function getFilterOptions($field)
    {
        $model = $this->getModel();
        return $model->getFilterOptions($field);
    }*/
}