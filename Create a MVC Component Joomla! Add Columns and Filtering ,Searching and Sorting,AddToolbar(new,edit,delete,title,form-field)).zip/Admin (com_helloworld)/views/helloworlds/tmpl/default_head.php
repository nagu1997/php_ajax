<?php
defined('_JEXEC') or die('access deny');
$this->state = $this->get('State');
$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn = $this->escape($this->state->get('list.direction'));
?>
<style>
    th{
        border:2px solid white;
        padding:8px;
        text-align: center;
        font-weight:bold;
		background-color:#f0f0f0;
    }
    
    
</style> 
<tr>
    
    <th width="5">
        <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items);?>);"/>
    </th>
    <th width="40%">
        <?php echo JHtml::_('grid.sort','NAME', 'a.name', $listDirn, $listOrder);?>
        <?php //echo HtmlHelper::_('searchtools.sort', 'NAME', 'a.name', $this->listDirn, $this->listOrder); ?>
    </th>
    <th width="5%">
		<?php echo JHtml::_('grid.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
        <?php //echo HtmlHelper::_('searchtools.sort', 'JSTATUS', 'a.published', $this->listDirn, $this->listOrder); ?>
	</th>
    <th>
        <?php echo JHtml::_('grid.sort','EMAIL', 'a.email', $listDirn, $listOrder);?>
    </th>
    <th>
        <?php echo JHtml::_('grid.sort','MOBILE_NO','a.mobileno', $listDirn, $listOrder);?>
    </th>
    <th>
        <?php echo JHtml::_('grid.sort','CITY','a.city', $listDirn, $listOrder);?>
    </th>
    <th width="10%">
		<?php echo JHtml::_('grid.sort', 'JCATEGORY', 'category_title', $listDirn, $listOrder); ?>
	</th>
    <th>
        <?php echo JHtml::_('grid.sort','JGRID_HEADING_ID','a.id', $listDirn, $listOrder);?>
        <?php //echo HtmlHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $this->listDirn, $this->listOrder); ?>
    </th>
    
</tr>