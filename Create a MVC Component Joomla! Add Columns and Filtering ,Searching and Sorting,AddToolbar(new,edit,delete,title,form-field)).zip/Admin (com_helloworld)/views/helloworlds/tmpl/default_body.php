<?php
defined('_JEXEC') or die('Restricted Access');
JHtml::addIncludePath(JPATH_COMPONENT.'/views/helloworld/tmpl');
JHtml::addIncludePath(JPATH_COMPONENT.'/views/helloworld/view.html.php');
?>

<style> 
    td{
        border:2px solid white;
        padding:8px;
		
    }
	.t1{
		color:#025A8D;
	}
	tr:nth-of-type(odd){
		background-color:white;
	}
	tr:nth-of-type(even){
		background-color:#f0f0f0;
	}
	tr:hover{
		background-color:#e8f6fe;
	}
	a{
        text-decoration:none;
    }
    a:hover{
        text-decoration: underline;
    }
</style>


<?php foreach($this->items as $i => $item): 
    $user		= JFactory::getUser();
	$userId		= $user->get('id');
	//$listOrder	= $this->escape($this->state->get('list.ordering'));
	//$listDirn	= $this->escape($this->state->get('list.direction'));
	//$ordering	= ($listOrder == 'ordering');
	//$item->id_link = JRoute::_('index.php?option=com_helloworld&view=helloworld&layout=edit&id='.$item->id);
	//$ordering	= ($listOrder == 'ordering');
	//$item->cat_link = JRoute::_('index.php?option=com_helloworld&view=helloworld&layout=edit&type=other&cid[]='. $item->catid);
	//$canCreate	= $user->authorise('core.create',		'com_helloworld.category.'.$item->catid);
	$canEdit	= $user->authorise('core.edit',			'com_helloworld.category.'.$item->catid);
	//$canCheckin	= $user->authorise('core.manage',		'com_checkin') || $item->checked_out == $userId || $item->checked_out == 0;
	//$canChange	= $user->authorise('core.edit.state',	'com_helloworld.category.'.$item->catid) && $canCheckin;
	?>
	<tr class="row<?php echo $i % 2; ?>" >
		<td class="center">
			<?php echo JHtml::_('grid.id', $i, $item->id); ?>
		</td>
		<td class="left t1">
			<?php if ($canEdit) : ?>
				<a href="<?php echo JRoute::_('index.php?option=com_helloworld&view=helloworld&layout=edit&id='.(int) $item->id); ?>">
					<?php echo $this->escape($item->name); ?></a>
			<?php else : ?>
					<?php echo $this->escape($item->name); ?>
			<?php endif; ?>
		</td>
		
		<td class="center">
			<?php echo JHtml::_('jgrid.published', $item->state, $i, 'helloworld.','cb'); ?>
		</td>
		<td class="center">
			<?php echo $item->email; ?>
		</td>
		<td class="center">
			<?php echo $item->mobileno; ?>
		</td>
		<td class="center">
			<?php echo $item->city; ?>
		</td>
		<td class="center">
			<?php echo $this->escape($item->category_title); ?>
		</td>
		<td class="center">
			<?php echo $item->id; ?>
		</td>
	</tr>
<?php endforeach; ?>