<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_banners
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

$published = $this->state->get('filter.published');
?>
<fieldset class="batch">
	<legend><?php echo JText::_('COM_HELLOWORLD_BATCH_OPTIONS');?></legend>
	<p><?php echo JText::_('COM_HELLOWORLD_BATCH_TIP'); ?></p>
	<?php echo JHtml::_('helloworld.id');?>
	<?php echo JHtml::_('helloworld.name');?>

	<?php if ($published >= 0) : ?>
		<?php echo JHtml::_('helloworld.item', 'com_helloworld');?>
	<?php endif; ?>

	<button type="submit" onclick="Joomla.submitbutton('helloworld.batch');">
		<?php echo JText::_('JGLOBAL_HELLOWORLD_PROCESS'); ?>
	</button>
	<button type="button" onclick="document.id('batch-id').value='';document.id('batch-name').value='';document.id('batch-email').value='';document.id('batch-mobileno').value=''">
		<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>
	</button>
</fieldset> 