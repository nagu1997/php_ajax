<?php
defined('_JEXEC') or die('access denied');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');

JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
//Get companie options
//JFormHelper::addFieldPath(JPATH_COMPONENT . '/models/fields');
//$optionsFilter = JFormHelper::loadFieldType('helloworld', false);
//$helloworldOptions = $optionsFilter->getOptions(); // works only if you set your field getOptions on public!!

//$user		= JFactory::getUser();
//$userId		= $user->get('id');
$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));
/*$params		= (isset($this->state->params)) ? $this->state->params : new JObject();
$optionsId = $this->getFilterOptions('id');
$optionsName = $this->getFilterOptions('name');
$optionsEmail = $this->getFilterOptions('email');
$optionsMobileNo = $this->getFilterOptions('mobileno');

// Assign filter options to the view
$this->optionsId = $optionsId;
$this->optionsName = $optionsName;
$this->optionsEmail = $optionsEmail;
$this->optionsMobileNo = $optionsMobileNo;*/

$searchterms = $this->state->get('filter.search');

//Highlight search terms with js (if we did a search => more performant and otherwise crash)
if (strlen($searchterms)>1) JHtml::_('behavior.highlighter', explode(' ',$searchterms));
?>

<style>
    table{
        border-collapse:collapse;
        padding:8px;
        width:100%;
		border: 2px solid white;
    }
	.highlight {  
		background: none repeat scroll 0 0 #FFFF00; 
	}
	option{
		color:black;
		background-color:blue;
	}
</style>

<form action="<?php echo JRoute::_('index.php?option=com_helloworld&view=helloworlds');?>" method="post" name="adminForm" id="adminForm">

    <fieldset id="filter-bar">
		<!--<div class="filter-search fltlft">
			<label class="filter-search-lbl" for="filter_search"><?php //echo JText::_('JSEARCH_FILTER_LABEL'); ?></label>
			<input type="text" name="filter_search" id="filter_search" value="<?php //echo $this->escape($this->state->get('filter.search')); ?>" title="<?php// echo JText::_('COM_HELLOWORLD_SEARCH_IN_TITLE'); ?>" />
			<button type="submit"><?php //echo JText::_('JSEARCH_FILTER_SUBMIT'); ?></button>
			<button type="submit" onclick="document.id('filter_search').value='';this.form.submit();"><?php //echo JText::_('JSEARCH_FILTER_CLEAR'); ?></button>
		</div>-->
		<div class="filter-search fltlft">
			<label class="filter-search-lbl" for="filter_search"><?php echo JText::_('JSEARCH_FILTER_LABEL'); ?></label>
			<input type="text" name="filter_search" id="filter_search" value="<?php echo $this->escape($this->searchterms); ?>" title="<?php echo JText::_('Search in helloworld form, etc...'); ?>" />
			<button type="submit">
				<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>
			</button>
			<button type="button" onclick="document.id('filter_search').value='';this.form.submit();">
				<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>
			</button>
		</div> 
		<div class="filter-select fltrt">

			<select name="filter_id" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo '- SELECT_ID -';?></option>
				<?php echo JHtml::_('select.options', HelloWorldHelper::getIdOptions(), 'value', 'text', $this->state->get('filter.id'), true);?>
			</select>

			<select name="filter_name" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo '- SELECT_NAME -'; ?></option>
				<?php echo JHtml::_('select.options', HelloWorldHelper::getNameOptions(), 'value', 'text', $this->state->get('filter.name'));?>
			</select>

			<select name="filter_email" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo '- SELECT_EMAIL -' ?></option>
				<?php echo JHtml::_('select.options', HelloWorldHelper::getEmailOptions(), 'value', 'text', $this->state->get('filter.email'));?>
			</select>

			<select name="filter_mobileno" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo '- SELECT_MOBILENO -';?></option>
				<?php echo JHtml::_('select.options', HelloWorldHelper::getMobilenoOptions(), 'value', 'text', $this->state->get('filter.mobileno'));?>
			</select>

			<select name="filter_city" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo '- SELECT_CITY -';?></option>
				<?php echo JHtml::_('select.options', HelloWorldHelper::getCityOptions(), 'value', 'text', $this->state->get('filter.city'));?>
			</select>

			<select name="filter_category" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_helloworld'), 'value', 'text', $this->state->get('filter.category'));?>
			</select>
		</div>
	</fieldset> 
	<!--<div class="clr"> </div> -->
	
    <table class="adminList">
        <thead><?php echo $this->loadTemplate('head');?></thead>
        <tfoot><?php echo $this->loadTemplate('foot');?></tfoot>
        <tbody><?php echo $this->loadTemplate('body');?></tbody>
    </table>
	
	
   <?php //Load the batch processing form. ?>
	<?php //if ($user->authorize('core.create', 'com_helloworld') && $user->authorize('core.edit', 'com_helloworld') && $user->authorize('core.edit.state', 'com_helloworld')) : ?>
		<?php //echo $this->loadTemplate('batch'); ?>
	<?php //endif;?>

    <!--adding a toolbar-->
    <div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>