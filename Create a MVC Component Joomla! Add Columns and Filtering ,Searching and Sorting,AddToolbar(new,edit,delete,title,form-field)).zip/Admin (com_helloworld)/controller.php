<?php
defined('_JEXEC') or die('access denied');
jimport('joomla.application.component.controller');
class HelloWorldController extends JController{
    function display($cachable=false,$urlparams=false){
        // set default view if not set
		$input = JFactory::getApplication()->input;
		$input->set('view', $input->getCmd('view', 'HelloWorlds'));

		// call parent behavior
		parent::display($cachable, $urlparams);
        
		// Set the submenu
		HelloWorldHelper::addSubmenu('messages');
        //HelloWorldHelper::getIdOptions();
    }
} 
?>