<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class HelloWorldControllerHelloWorlds extends JControllerAdmin{
	public function getModel($name = 'HelloWorld', $prefix = 'HelloWorldModel') {
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));
		return $model;
	}
}
?>