DROP TABLE IF EXISTS `#__helloworld`;

CREATE TABLE `#__helloworld` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `mobileno` varchar(20) NOT NULL,
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

INSERT INTO `#__helloworld` (`name`,`email`,`mobileno`) VALUES
	('Naga Murugan','nagamurugan1997@gmail.com',9600043308),
	('Deivendran','dd6@gmail.com',6374480585),
  ('Tamilselvi','tamilselvit57@gmail.com',7603895695);
