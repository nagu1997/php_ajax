<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.form.formrule');

class JFormRuleMobileno extends JFormRule
{
	protected $regex = '^\d+$';
}