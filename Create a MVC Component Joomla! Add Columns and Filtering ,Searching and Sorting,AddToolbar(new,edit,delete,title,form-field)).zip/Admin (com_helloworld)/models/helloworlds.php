<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.modellist');
class HelloWorldModelHelloWorlds extends JModelList{
	/*protected function getListQuery(){		
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('id,name,email,mobileno');
		$query->from('#__helloworld');
		return $query;
	}*/
	/*public function getFilterOptions($field)
    {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query->select("DISTINCT $field");
        $query->from("#__helloworld");

        $db->setQuery($query);
        $options = $db->loadColumn();

        return $options;
    }*/

    //Add this handy array with database fields to search in
	/*protected $searchInFields = array('text','a.name','someotherfieldtosearchin');

    //Override construct to allow filtering and ordering on our fields
    public function __construct($config = array()) {
        $config['filter_fields']=array_merge($this->searchInFields,array('a.name'));
        parent::__construct($config);
    }*/
    
    /**
	 * Method to get the maximum ordering value for each category.
	 *
	 * @since	1.6
	 */
	/*function &getCategoryOrders()
	{
		if (!isset($this->cache['categoryorders'])) {
			$db		= $this->getDbo();
			$query	= $db->getQuery(true);
			$query->select('MAX(ordering) as '.$db->quoteName('max').', catid');
			$query->select('catid');
			$query->from('#__helloworld');
			$query->group('catid');
			$db->setQuery($query);
			$this->cache['categoryorders'] = $db->loadAssocList('catid', 0);
		}
		return $this->cache['categoryorders'];
	}*/

	///sorting values filtered............
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id', 'a.id',
				'cid', 'a.cid', 
				'name', 'a.name',
				'city', 'a.city',
				'state', 'a.state',
				'catid', 'a.catid', 'category_title',
				'state',
			);
		}
 
		parent::__construct($config);
	}
    protected function getListQuery()
	{
		// Initialise variables.
		$db		= $this->getDbo();
		$query	= $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'a.id AS id, a.name AS name, a.email AS email,a.mobileno AS mobileno,'.
				'a.city AS city,' .
				'a.catid AS catid,' .
				'a.state AS state'
			)
		);
		$query->from($db->quoteName('#__helloworld').' AS a');
		

        // Join over the categories.
		$query->select('c.title AS category_title');
		$query->join('LEFT', '#__categories AS c ON c.id = a.catid');
        
		// Filter by 
		$id = $this->getState('filter.id');
		if ($id) {
			$query->where('a.id = '.(int) $id);
            //echo($query->__toString());
		}
		if ($name = $this->getState('filter.name')) {
			$query->where('a.name = "' .$name.'"' );
            //echo($query->__toString());
		}
		if ($city = $this->getState('filter.city')) {
			$query->where('a.city = "' .$city.'"' );
			$query->group('a.city');
            echo($query->__toString());
		}
        if ($email = $this->getState('filter.email')) {
			$query->where('a.email = ' . $db->quote($email));
			$query->group('a.email');
           // echo($query->__toString());
		}
        $mobileno = $this->getState('filter.mobileno');
		if ($mobileno) {
			$query->where('a.mobileno = '.$db->quote($mobileno));
            //echo($query->__toString());
		}

       // Filter by category.
		$categoryId = $this->getState('filter.category_id');
		if ($categoryId) {
			$query->where('a.catid = '.(int) $categoryId);
			$query->group('a.catid');
		}


		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = '.(int) substr($search, 3));
			} else {
				$search = $db->Quote('%'.$db->escape($search, true).'%');
				$query->where('(a.name LIKE '.$search.')');
			}
		}

		// Add list ordering clause
		$orderCol = $this->state->get('list.ordering', 'a.name');
		$orderDirn = $this->state->get('list.direction', 'desc');

		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

		//echo nl2br(str_replace('#__','jos_',$query));

		//$query->order($db->escape($this->getState('list.ordering', 'name')).' '.$db->escape($this->getState('list.direction', 'ASC')));
		return $query;
	}


   /* protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id	.= ':'.$this->getState('filter.search');
        $id .= ':'.$this->getState('filter.name');
        $id	.= ':'.$this->getState('filter.state');
        $id .= ':'.$this->getState('filter.email');
        $id .= ':'.$this->getState('filter.mobileno');
        $id	.= ':'.$this->getState('filter.category_id');
		$id	.= ':'.$this->getState('filter.id');
		return parent::getStoreId($id);
	}
        
    public function getTable($type = 'helloworld', $prefix = 'HelloWorldsTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}*/
    /**
     * Method to auto-populate the model state.
     *
     * Note. Calling getState in this method will result in recursion.
     *
     * @since	1.6
     */
    protected function populateState($ordering = null, $direction = null)
    {
        // Initialise variables.
        $app = JFactory::getApplication('administrator');
    
        // Load the filter state.
        $search = $app->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
        //Omit double (white-)spaces and set state
        $this->setState('filter.search', preg_replace('/\s+/',' ', $search));
        
        //Filter (dropdown) state
        $id = $app->getUserStateFromRequest($this->context.'.filter.id', 'filter_id');
        $this->setState('filter.id', $id);

        //Filter (dropdown) company
        $name= $app->getUserStateFromRequest($this->context.'.filter.name', 'filter_name','');
        $this->setState('filter.name', $name);

        //Filter (dropdown) company
        $email= $app->getUserStateFromRequest($this->context.'.filter.email', 'filter_email','','string');
        $this->setState('filter.email', $email);

		//Filter (dropdown) company
        $city= $app->getUserStateFromRequest($this->context.'.filter.city', 'filter_city','');
        $this->setState('filter.city', $city);

        //Filter (dropdown) company
        $mobileno= $app->getUserStateFromRequest($this->context.'.filter.mobileno', 'filter_mobileno','','string');
        $this->setState('filter.mobileno', $mobileno);

        $categoryId = $this->getUserStateFromRequest($this->context.'.filter.category_id', 'filter_category_id', '');
		$this->setState('filter.category_id', $categoryId);

        $state = $this->getUserStateFromRequest($this->context.'.filter.state', 'filter_state', '', 'string');
		$this->setState('filter.state', $state);
    
        //Takes care of states: list. limit / start / ordering / direction
        parent::populateState('a.name', 'asc');
    }
}