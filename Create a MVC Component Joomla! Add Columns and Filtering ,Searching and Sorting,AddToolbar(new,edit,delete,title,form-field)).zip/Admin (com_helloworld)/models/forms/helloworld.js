window.addEvent('domready', function() {
	document.formvalidator.setHandler('name',
		function (value) {
			regex=/^[^0-9]+$/;
			return regex.test(value);
	});
    document.formvalidator.setHandler('mobileno',
		function (value) {
			regex=/^\d+$/;
			return regex.test(value);
	});
});