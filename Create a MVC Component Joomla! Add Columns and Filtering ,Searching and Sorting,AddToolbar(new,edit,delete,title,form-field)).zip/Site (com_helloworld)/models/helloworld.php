<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.modelitem');
class HelloWorldModelHelloWorld extends JModelItem{
	protected $messages;
	public function getTable($type = 'HelloWorld', $prefix = 'HelloWorldTable', $config = array()) 
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	public function getMsg($id = 1) 
	{
		if (!is_array($this->messages))
		{
			$this->messages = array();
		}
		
		if (!isset($this->messages[$id])) {
			$jinput = JFactory::getApplication()->input;
			$id = $jinput->get('id', 1, 'INT' );
			$table = $this->getTable();
			$table->load($id);
			$this->messages[$id] = $table->name;
			$this->messages[$id] = $table->email;
			$this->messages[$id] = $table->mobileno;
		}
		
		return $this->messages[$id];
	}

	protected function populateState($ordering = null, $direction = null)
    {
        // Initialise variables.
        $app = JFactory::getApplication();
    
        // Load the filter state.
        $search = $app->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
        //Omit double (white-)spaces and set state
        $this->setState('filter.search', preg_replace('/\s+/',' ', $search));
        
        //Filter (dropdown) state
        $id = $app->getUserStateFromRequest($this->context.'.filter.id', 'filter_id', '');
        $this->setState('filter.id', $id);

        //Filter (dropdown) company
        $name= $app->getUserStateFromRequest($this->context.'.filter.name', 'filter_name', '');
        $this->setState('filter.name', $name);

        //Filter (dropdown) company
        $email= $app->getUserStateFromRequest($this->context.'.filter.email', 'filter_email', '');
        $this->setState('filter.email', $email);

        //Filter (dropdown) company
        $mobileno= $app->getUserStateFromRequest($this->context.'.filter.mobileno', 'filter_mobileno', '');
        $this->setState('filter.mobileno', $mobileno);
    
        //Takes care of states: list. limit / start / ordering / direction
        parent::populateState('a.name', 'asc');
    }
}