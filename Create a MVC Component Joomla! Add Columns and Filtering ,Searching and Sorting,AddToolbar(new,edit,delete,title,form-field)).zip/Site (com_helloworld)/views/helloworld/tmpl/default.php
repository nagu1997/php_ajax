<?php
defined('_JEXEC') or die('access deny');
?>
<h1><?php echo $this->msg; ?></h1>