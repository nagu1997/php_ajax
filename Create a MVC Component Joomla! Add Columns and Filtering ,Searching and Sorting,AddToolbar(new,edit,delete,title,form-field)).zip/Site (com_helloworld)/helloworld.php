<?php
defined('_JEXEC') or die ('access deny');



jimport('joomla.application.component.controller');
$controller=Jcontroller::getInstance('Helloworld');
$input=JFactory::getApplication()->input;
$controller->execute($input->getCmd('task'));
$controller->redirect();
?>