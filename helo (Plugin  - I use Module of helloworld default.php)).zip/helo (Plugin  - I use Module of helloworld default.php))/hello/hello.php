<?php

// no direct access
defined('_JEXEC') or die;

class plgHeloHello extends JPlugin
{
      /* public function __construct(& $subject, $config)
        {
                $this->loadLanguage();
                parent::__construct($subject, $config);
        }*/
       
        public function getCities($citypara){  
                // These all are local field. so, easily Get!
                $word =  $this->params->get('field1',"");
                $word2 =  $this->params->get('field2',"");
                $myarea = $this->params->get('parentcity',0);
                $result = array();
                if (!empty($citypara)) {
                        foreach($citypara as $para){
                                $result[]->name = $word .$para->name .$word2 .$myarea;
                                        
                                
                        }
                        //print_r($result);
                }
                return $result;
        }
}
  
?>