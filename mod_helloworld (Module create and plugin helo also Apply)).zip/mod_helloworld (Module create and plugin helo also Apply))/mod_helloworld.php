<?php
defined('_JEXEC') or die('access denied');
//require_once dirname(__FILE__).'/helper.php';


//$language = $params->get('lang', '2');
//$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));


//$selectedCategory = (int) $params->get('category', 0);

//$customData = modHelloWorldHelper::getHello($params);

//require JModuleHelper::getLayoutPath('mod_helloworld', $params->get('layout', 'default'));

/*
// Include the model
JModelLegacy::addIncludePath(JPATH_BASE . '/modules/mod_helloworld/models');
$model = JModelLegacy::getInstance('Helloworld', 'ModHelloworldModel', array('ignore_request' => true));

// Get data from the model
$categories = $model->getCategories();

// Include the view
JFactory::getLanguage()->load('mod_helloworld');
$view = $model->getView('Helloworld', 'html');
$view->categories = $categories;

// Display the view
$view->display();

*/

require_once dirname(__FILE__).'/helper.php';


$categoryId = (int) $params->get('parent', 0);
$categories = modHelloWorldHelper::getHello($categoryId);

$mycity =  $params->get('parentcity',0);
$cities = modHelloWorldHelper::getCity($mycity);


//$cities_title = modHelloWorldHelper::getCityTitle($mycity);
$category_title = modHelloWorldHelper::getCategoryTitle($categoryId);
$allNames = modHelloWorldHelper::getAllNames();

require JModuleHelper::getLayoutPath('mod_helloworld', $params->get('layout', 'default'));
?> 