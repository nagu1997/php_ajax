<?php
defined('_JEXEC') or die('access denied');


class modHelloWorldHelper{
    public static function getHello($params){
        // Obtain a database connection
        $db = JFactory::getDbo();
        // Retrieve the shout
       // $query = $db->getQuery(true);
       //->select($db->quoteName('name'))->from($db->quoteName('#__helloworld'))->where('cid');

       // Select the required fields from the table.
		/*$query->select($db->quoteName('email'));
		$query->from($db->quoteName('#__helloworld').' AS a');
        $query->where('state= '. $db->Quote('published'));*/

        // Join over the categories.
		//$query->select('c.title AS category_title');
        //$query->from('#__helloworld AS a');
		//$query->join('LEFT', '#__categories AS c ON c.id = a.catid');

        // Filter by 
		/*$id = $this->getState('filter.id');
		if ($id) {
			$query->where('a.id = '.(int) $id);
            echo($query->__toString());
		}*/


       // Get the selected category from the module parameters

        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__helloworld AS a');
        $query->where('a.catid ='. (int) $params);
        
       
      /* $query =$db->getQuery(true)->select($db->quoteName('name'))
            ->from($db->quoteName('#__helloworld'))
            ->where('id = '. $db->Quote($params));*/

        // Prepare the query
        $db->setQuery($query);
        // Load the row.
        $result = $db->loadObjectList();
        // Return the Hello
        return $result;
    } 

    public static function getCategoryTitle($params){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('c.title');
        $query->from('#__categories AS c');
        $query->where('c.id ='. (int) $params);
        $db->setQuery($query);
        $result = $db->loadObject();
        return $result;
    }

    public static function getCity($params){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('a.name,a.city');
        $query->from('#__helloworld AS a');
        $query->where('a.city ='. $db->Quote($params));
        $db->setQuery($query);
        $result = $db->loadObjectList();
        return $result;
    }

    public static function getCityTitle($params){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('a.city');
        $query->from('#__helloworld AS a');
        $query->where('a.city ='. $db->Quote($params));
        $db->setQuery($query);
        $result = $db->loadObject();
        return $result;
    }

    public static function getAllNames(){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__helloworld AS a');
        $db->setQuery($query);
        $result = $db->loadObjectList();
        return $result;
    }


}
?>