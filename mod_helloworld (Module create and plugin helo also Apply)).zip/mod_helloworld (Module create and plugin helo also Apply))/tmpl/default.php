<?php
defined('_JEXEC') or die;
//var_dump($categories);

echo '<div style="overflow:auto;height:100px;width:200px;">';
$i=0;
if (!empty($categories)) {

    
    echo '<h2>CATEGORY - <u>' .$category_title->title. '</u></h2>';
    foreach ($categories as $category) {
        $i++;   
        //$category->id = sprintf('%02d', $category->id);
        //if($category->state==1){
        //$category->state = "published";
        echo '<p>' . $i . '.'. $category->name .'</p>';
        //echo '<p style="width:450px;">' . $category->id .' . '. $category->name . ' , '. $category->email . ' , '. $category->mobileno .' , '. $category->state .'</p>';
      //  }else{
           // $category->state = "unpublished";
           // echo '<p style="width:450px;">' . $category->id .' . '. $category->name . ' , '. $category->email . ' , '. $category->mobileno .' , '. $category->state .'</p>';
       // }
    }
} else {
   // echo 'No categories found.';
   echo '<h3 style="color:black;>---<u><b>ALL CATEGORIES</b></u>---</h3>';
   foreach ($allNames as $all) {
        $i++;
        echo '<p>' . $i . '.' . $all->name . '</p>';
   }        
}
echo '</div>';







echo '<hr><br/>';

echo '<div style="overflow:auto;height:100px;width:200px;">';


    JPluginHelper::importPlugin( 'helo' );
    $dispatcher	=& JDispatcher::getInstance();
    $cityResult = $dispatcher->trigger('getCities',array($cities));
    if(isset($cityResult[0])){
        $cities =  $cityResult[0];
    }
           //print_r($cities);
           if(!empty($cities)){
            foreach($cities as $res){
                echo $res->name . '<br><br>';
            }
        }


echo '</div>';










?>
